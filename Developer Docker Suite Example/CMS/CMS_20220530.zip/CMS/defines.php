<?php
//define('COCKPIT_DIR', '/var/www/html');
//define("COCKPIT_ADMIN", '0');
//define("COCKPIT_DOCS_ROOT", '/var/www/html');
//define("COCKPIT_ENV_ROOT", '/var/www/html');
//define("COCKPIT_BASE_URL", '/cms'); // This one breaks API
// define("COCKPIT_API_REQUEST", ''); // If 0 UI works, if 1 API works
//define("COCKPIT_BASE_ROUTE", '/cms'); // This one add 'cms' after URL
//define("COCKPIT_SITE_DIR", '/var/www/html');
//define("COCKPIT_CONFIG_DIR", '/var/www/html/config');
//define("COCKPIT_PUBLIC_STORAGE_FOLDER", '/var/www/html/storage');
//define("COCKPIT_ADMIN_CP", '1'); // If 0 UI stops working
//define("COCKPIT_CONFIG_PATH ", '/var/www/html/config/config.php');
//define("COCKPIT_STORAGE_FOLDER", '/var/www/html/storage');
