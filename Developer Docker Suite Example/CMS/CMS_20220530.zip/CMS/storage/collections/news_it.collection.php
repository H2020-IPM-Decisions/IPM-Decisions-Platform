<?php
 return array (
  'name' => 'news_it',
  'label' => 'News in Italian',
  '_id' => 'news_it',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => 'Titolo',
      'type' => 'text',
      'default' => '',
      'info' => 'Titolo News',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'content',
      'label' => 'Contenuto',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => 'Contenuto della notizia',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1638815643,
  '_modified' => 1638815643,
  'color' => '',
  'acl' => 
  array (
  ),
  'sort' => 
  array (
    'column' => '_created',
    'dir' => -1,
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
  'description' => 'News translated in italian',
);