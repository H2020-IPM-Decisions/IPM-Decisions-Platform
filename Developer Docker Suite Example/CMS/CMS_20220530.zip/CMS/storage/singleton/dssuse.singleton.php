<?php
 return array (
  'name' => 'dssuse',
  'label' => 'DSS use',
  '_id' => 'dssuse5e45ccf6e1428',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'description',
      'label' => '',
      'type' => 'textarea',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1581632758,
  '_modified' => 1591698597,
  'description' => '',
  'acl' => 
  array (
  ),
);