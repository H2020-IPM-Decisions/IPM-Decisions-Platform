<?php
 return array (
  'name' => 'termsandconditions',
  'label' => 'Terms and Conditions',
  '_id' => 'termsandconditions',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'en',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'it',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => false,
    ),
  ),
  'data' => NULL,
  '_created' => 1639476320,
  '_modified' => 1639476320,
  'description' => '',
  'acl' => 
  array (
  ),
);