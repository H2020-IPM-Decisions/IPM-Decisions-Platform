<?php
 return array (
  'name' => 'termsnconditions',
  'label' => 'Terms & Conditions',
  '_id' => 'termsnconditions5e4d4e234234b',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'content',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1582124579,
  '_modified' => 1594031402,
  'description' => '',
  'acl' => 
  array (
  ),
);