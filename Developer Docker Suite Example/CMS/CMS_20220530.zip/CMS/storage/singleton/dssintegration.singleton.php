<?php
 return array (
  'name' => 'dssintegration',
  'label' => 'DSS integration',
  '_id' => 'dssintegration5e45cd68d33b4',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'description',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1581632872,
  '_modified' => 1582047463,
  'description' => '',
  'acl' => 
  array (
  ),
);