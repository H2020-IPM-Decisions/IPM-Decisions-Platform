<?php
 return array (
  'name' => 'dssevaluation',
  'label' => 'DSS evaluation',
  '_id' => 'dssevaluation5e45cd21479d0',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'description',
      'label' => '',
      'type' => 'textarea',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'image',
      'label' => 'image',
      'type' => 'image',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => false,
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1581632801,
  '_modified' => 1591698731,
  'description' => '',
  'acl' => 
  array (
  ),
);