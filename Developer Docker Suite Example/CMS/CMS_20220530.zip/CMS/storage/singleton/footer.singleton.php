<?php
 return array (
  'name' => 'footer',
  'label' => 'Footer',
  '_id' => 'footer5dcc3865533e0',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'content',
      'label' => '',
      'type' => 'html',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1573664869,
  '_modified' => 1582288730,
  'description' => '',
  'acl' => 
  array (
  ),
);