<div>
    <ul class="uk-breadcrumb">
        <li class="uk-active"><span><?php echo $app("i18n")->get('Assets'); ?></span></li>
    </ul>
</div>

<div riot-view>
    <cp-assets></cp-assets>
</div>
