<?php
 return array (
  'name' => 'dssadaptation',
  'label' => 'DSS adaptation',
  '_id' => 'dssadaptation5e45cd465fc50',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'description',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1581632838,
  '_modified' => 1582047368,
  'description' => '',
  'acl' => 
  array (
  ),
);