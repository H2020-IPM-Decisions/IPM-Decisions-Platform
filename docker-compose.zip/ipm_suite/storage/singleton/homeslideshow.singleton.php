<?php
 return array (
  'name' => 'homeslideshow',
  'label' => 'Home Slideshow',
  '_id' => 'homeslideshow5e4c2d121b7de',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'gallery',
      'label' => '',
      'type' => 'gallery',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1582050578,
  '_modified' => 1582288793,
  'description' => '',
  'acl' => 
  array (
  ),
);