<?php
 return array (
  'name' => 'banner',
  'label' => 'Banner',
  '_id' => 'banner5e442b719c13d',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1581525873,
  '_modified' => 1582047295,
  'description' => '',
  'acl' => 
  array (
  ),
  'icon' => 'photo.svg',
);